﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ShopSystem.Models
{
    public class LoginInfo
    {
        public string Phone { get; set; }
        public string PW { get; set; }
    }
}