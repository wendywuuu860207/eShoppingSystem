﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ShopSystem.Models
{
    public class MemberInfo
    {
        public string Name { get; set; }
        public string Phone { get; set; }
        public string PW { get; set; }
        public string oldPW { get; set; }
        public string Email { get; set; }
        
    }
}